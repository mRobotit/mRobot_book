#include "stm32f10x.h"
#include "motor.h"
#include "stm32f10x_exti.h"

#define ENCODER_TIM_PERIOD (u16)0xFFFF
#define MAX_COUNT          (u16)0x0FFF

int leftcount;
int rightcount;


void LEFT_Motor_Init(void)
{
/*定义一个GPIO_InitTypeDef类型的结构体*/
	GPIO_InitTypeDef GPIO_InitStructure;

  	/*开启GPIOB的外设时钟*/
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);

  	/*选择要控制的GPIOB引脚*/															   
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;	

		/*设置引脚模式为通用推挽输出*/
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   

  	/*设置引脚速率为50MHz */    
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  	/*调用库函数，初始化GPIOB*/
  	GPIO_Init(GPIOA, &GPIO_InitStructure);		  

		/* 初始化低电平	*/
		GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5);
}


void RIGHT_Motor_Init(void)
{
/*定义一个GPIO_InitTypeDef类型的结构体*/
	GPIO_InitTypeDef GPIO_InitStructure;

  	/*开启GPIOB的外设时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); 

  	/*选择要控制的GPIOB引脚*/															   
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_12;	

		/*设置引脚模式为通用推挽输出*/
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   

  	/*设置引脚速率为50MHz */    
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  	/*调用库函数，初始化GPIOB*/
  	GPIO_Init(GPIOB, &GPIO_InitStructure);		  

		/* 初始化低电平	*/
		GPIO_SetBits(GPIOB, GPIO_Pin_1 | GPIO_Pin_12);
}

void LEFT_PWM_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	u16 CCR2_Val = 0;
	/*打开GPIOA时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	/*打开TIM1时钟*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  /*GPIOA 引脚配置 */
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;		  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  /*GPIOA 初始化 */
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* 定时器基本设置*/		 
  TIM_TimeBaseStructure.TIM_Period =  7199;     						  // 当定时器从0计数到999，即为1000次，为一个定时周期
  TIM_TimeBaseStructure.TIM_Prescaler = 0;	  						    //设置预分频：不预分频，即为72MHz
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1 ;		//设置时钟分频系数：不分频
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //向上计数模式

  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

   /*Chanle1配置 */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	    //配置为PWM模式1
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;	//比较输出使能
  TIM_OCInitStructure.TIM_Pulse = CCR2_Val;	   //设置跳变值，当计数器计数到这个值时，电平发生跳变
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  //当定时器计数值小于CCR1_Val时为高电平
  TIM_OC2Init(TIM2, &TIM_OCInitStructure);	 //使能通道1
	
	TIM_CtrlPWMOutputs(TIM2,ENABLE);	                 				 //MOE 主输出使能

  TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM2, ENABLE);                   //使能TIMx在ARR上的预装载寄存器

	TIM_Cmd(TIM2, ENABLE);                                //使能TIM1
}


/*
void RIGHT_PWM_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	u16 CCR3_Val = 0;
  
	//打开TIM1时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	//打开GPIOB时钟
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	//配置引脚
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0;	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;		  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);				
  //定时器基本设置	 
  TIM_TimeBaseStructure.TIM_Period =  7200;     						  // 当定时器从0计数到999，即为1000次，为一个定时周期
  TIM_TimeBaseStructure.TIM_Prescaler = 0;	  						    //设置预分频：不预分频，即为72MHz
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1 ;		//设置时钟分频系数：不分频
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //向上计数模式

  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

  Channe1配置 
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	    //配置为PWM模式1
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;	//比较输出使能
  TIM_OCInitStructure.TIM_Pulse = CCR3_Val;	   //设置跳变值，当计数器计数到这个值时，电平发生跳变
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  //当定时器计数值小于CCR1_Val时为高电平
  TIM_OC3Init(TIM3, &TIM_OCInitStructure);	 //使能通道1
	TIM_CtrlPWMOutputs(TIM3,ENABLE);	                 				 //MOE 主输出使能

  TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM3, ENABLE);                   //使能TIMx在ARR上的预装载寄存器

	TIM_Cmd(TIM3, ENABLE);                                //使能TIM1
}
*/
void RIGHT_PWM_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	u16 CCR2_Val = 0;
  
	//打开TIM1时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	//打开GPIOB时钟
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	//开启AFIO时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	//Timer1部分重映射 
	
	GPIO_PinRemapConfig(GPIO_PartialRemap_TIM1, ENABLE); 
	//配置引脚
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0;	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;		  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);				
  //定时器基本设置	 
  TIM_TimeBaseStructure.TIM_Period =  7199;     						  // 当定时器从0计数到999，即为1000次，为一个定时周期
  TIM_TimeBaseStructure.TIM_Prescaler = 0;	  						    //设置预分频：不预分频，即为72MHz
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1 ;		//设置时钟分频系数：不分频
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //向上计数模式

  TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

  //Channe1配置 
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	    //配置为PWM模式1
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Disable;
  TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;  	//比较输出使能
  TIM_OCInitStructure.TIM_Pulse = CCR2_Val;	   //设置跳变值，当计数器计数到这个值时，电平发生跳变
  TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCPolarity_High;  //当定时器计数值小于CCR1_Val时为高电平
  TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);	 //使能通道1
	TIM_CtrlPWMOutputs(TIM1,ENABLE);	                 				 //MOE 主输出使能

  TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM1, ENABLE);                   //使能TIMx在ARR上的预装载寄存器

	TIM_Cmd(TIM1, ENABLE);                                //使能TIM1
}
//控制电机转速以及方向
void PWM_OUTPUT(int Pwm,int MotorId)
{

	if(MotorId == MOTO_LEFT )
	{
		if(Pwm >0){
		  GPIO_SetBits(GPIOA, GPIO_Pin_5 );			   //电机控制模块BIN1端 PB14		    
      GPIO_ResetBits(GPIOA, GPIO_Pin_4 );       //电机控制模块BIN2端 PB15	
			
		}else
		{
			GPIO_SetBits(GPIOA, GPIO_Pin_4 );			   //电机控制模块BIN1端 PB15		    
      GPIO_ResetBits(GPIOA, GPIO_Pin_5 );       //电机控制模块BIN2端 PB14	
		Pwm = - Pwm;
		
		}
		TIM_SetCompare2(TIM2,Pwm);	
//		TIM_SetCompare3(TIM3,Pwm);				
	}else if(MotorId == MOTO_RIGHT){
		if(Pwm > 0){
		  GPIO_ResetBits(GPIOB, GPIO_Pin_1 );			   //电机控制模块BIN1端 PB13		    
      GPIO_SetBits(GPIOB, GPIO_Pin_12 );       //电机控制模块BIN2端 PB12	
		
		}else
		{
			GPIO_SetBits(GPIOB, GPIO_Pin_1 );			   //电机控制模块BIN1端 PB12		    
      GPIO_ResetBits(GPIOB, GPIO_Pin_12 );       //电机控制模块BIN2端 PB13	
		Pwm = - Pwm;
		}
		//TIM_SetCompare2(TIM2,Pwm);	
		TIM_SetCompare2(TIM1,Pwm);			       

	}
}
