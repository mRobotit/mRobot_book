/**
 * 
 *   Website	: http://www.mrobotit.cn/
 * 	 Author 	: Xiao Dong
 * 	 Description: 定时器，每间隔100ms计算电机转动速度
 * 	 Date		: 2020/11
 * 	 
 */

#include "timer.h"
#include "encoder.h"
#include "pid.h"
#include "usart.h"

extern unsigned int Safeware_Count1 =0;

void EXTI15_10_IRQHandler(void) 
{                                                         
	EXTI_ClearITPendingBit(EXTI_Line13);                            //===清除LINE12线路挂起位		
	(Safeware_Count1 >= 42949672) ?(Safeware_Count1=0) : (Safeware_Count1++);	//时间基数常数
		//if(Safeware_Count1 == 2000)
			//	Kinematics_Positive(0.5, 0.0);		//正向启动
		//else if(Safeware_Count1 == 20000)
			//	Kinematics_Positive(-0.5, 0.0);
	//	else if (Safeware_Count1 == 40000)
			//	Kinematics_Positive(0,  0.0);
		Robot_Encoder_Get_CNT();
		//PID控制左右轮Z
		Pid_Control_speed(Left_moto.Encoder_Value,Left_moto.Target_Encoder,MOTO_LEFT);
	  Pid_Control_speed(Right_moto.Encoder_Value,Right_moto.Target_Encoder,MOTO_RIGHT);
			
		//PWM控制左右电机
		PWM_OUTPUT(Left_moto.ESC_Output_PWM, MOTO_LEFT);
		PWM_OUTPUT(Right_moto.ESC_Output_PWM, MOTO_RIGHT);
} 


void Timer_Exit_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;  
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);          //外部中断，需要使能AFIO时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);        //使能GPIO端口时钟
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;	                 //端口配置
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;                //上拉输入
	GPIO_Init(GPIOC, &GPIO_InitStructure);					     //根据设定参数初始化GPIO
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC,GPIO_PinSource13);
	
	EXTI_InitStructure.EXTI_Line=EXTI_Line13;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;      //下降沿触发
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);	 	                         //根据EXTI_InitStruct中指定的参数初始化外设EXTI寄存器
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;		 //使能外部中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02; //抢占优先级2， 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;		 //子优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			     //使能外部中断通道
	NVIC_Init(&NVIC_InitStructure); 
}