#include "stdio.h"	
#include <stdbool.h>
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"


#define PROTOCOL_HEADER		0XFEFEFEFE
#define PROTOCOL_END		0XEE

#define PROTOCL_DATA_SIZE 49
#define PROTOCL_CONTROL_DATA_SIZE 25

#pragma pack(1)
typedef struct
{
	short X_data;
	short Y_data;
	short Z_data;
}Imu_Info;

typedef union   
{
	unsigned char buffer[PROTOCL_DATA_SIZE];
	struct
	{
		unsigned int Header;
		float X_speed;			
		float Y_speed;
		float Z_speed;
		float Adc_Voltage;
		
		
		float quat_x;
		float quat_y;
		float quat_z;
		float quat_w;
		
		Imu_Info Imu_Acc;
		Imu_Info Imu_Gyro;
		
		
		unsigned char End_flag;
	}Sensor_Info;
}Board_data;

typedef union   
{
	unsigned char buffer[PROTOCL_CONTROL_DATA_SIZE];
	struct
	{
		unsigned int Header;
		unsigned int kp;
		unsigned int ki;
		unsigned int kd;
		float X_speed;			
		float Z_speed;
		unsigned char End_flag;
	}Control_Info;
}Control_data;


#pragma pack(4)

extern Board_data Send_Data ;
extern Control_data Recive_Data;
extern float  KP , KI, KD ;


void USART1_Config(void); 

void USART2_Config(void); 

void USART3_Config(void); 

void USART_SendChar(USART_TypeDef *USARTx,unsigned char b);

void USART_Printf(USART_TypeDef* USARTx, uint8_t *Data,...);

void USART1_Send_Byte(USART_TypeDef *USARTx,unsigned char byte);

void PrintChar(char *s);

void Vcan_sendware(uint8_t *wareaddr, uint32_t waresize);

void Kinematics_Positive(float vx,float vz);

void Usart_SendTo_Ubuntu();
