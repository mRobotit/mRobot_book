#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
extern unsigned int Safeware_Count;
void Timerx_Init(u16 arr,u16 psc); 

void Timer_Exit_Init(void);
#endif
