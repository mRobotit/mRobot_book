
#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"

typedef struct _Moto_
{
	int Encoder_Value;
	float Current_Speed;
	float Target_Speed;
	int Target_Encoder;
	short ESC_Output_PWM;
	float L_Error;
	float LL_Error;
}Moto_Info;


extern Moto_Info Left_moto;
extern Moto_Info Right_moto;
	

#define ESC_OUTPUT_PWM_LIMT 5000
#define CONTROL_TIMER_CYCLE			0.01f	
#define Pi						3.1415f
#define Base_Width					0.154f
#define ROBOT_INITIATIVE_DIAMETER_L 0.062f
#define ROBOT_INITIATIVE_DIAMETER_R 0.062f
//#define Base_Width					0.216f
//#define ROBOT_INITIATIVE_DIAMETER_L 0.088f
//#define ROBOT_INITIATIVE_DIAMETER_R 0.088f
#define MOTO_LEFT		1
#define MOTO_RIGHT		2



void LEFT_Motor_Init(void);

void RIGHT_Motor_Init(void);

void LEFT_PWM_Init(void);

void RIGHT_PWM_Init(void);


void PWM_OUTPUT(int Pwm,int MotorId);

#endif
